#!/usr/bin/env node
/**
 * setup.js — Downloads llama-server.exe for Valley Open
 * Run: node scripts/setup.js
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const BIN_DIR = path.join(__dirname, '..', 'bin');
const LLAMA_EXE = path.join(BIN_DIR, 'llama-server.exe');

// Latest llama.cpp release with CUDA + CPU builds
// You can manually update this URL to a newer release
const RELEASE_URL = 'https://api.github.com/repos/ggerganov/llama.cpp/releases/latest';

async function getLatestRelease() {
  return new Promise((resolve, reject) => {
    https.get(RELEASE_URL, {
      headers: { 'User-Agent': 'ValleyOpen-Setup/1.0' }
    }, (res) => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        try {
          const release = JSON.parse(data);
          resolve(release);
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
}

async function downloadFile(url, dest) {
  return new Promise((resolve, reject) => {
    function doGet(url) {
      https.get(url, { headers: { 'User-Agent': 'ValleyOpen-Setup/1.0' } }, (res) => {
        if (res.statusCode === 301 || res.statusCode === 302) {
          doGet(res.headers.location);
          return;
        }
        const total = parseInt(res.headers['content-length'] || '0');
        let done = 0;
        const file = fs.createWriteStream(dest);
        res.on('data', chunk => {
          done += chunk.length;
          file.write(chunk);
          if (total) {
            process.stdout.write(`\r  ${(done/1024/1024).toFixed(1)} MB / ${(total/1024/1024).toFixed(1)} MB (${Math.round(done/total*100)}%)`);
          }
        });
        res.on('end', () => { file.end(); console.log(''); resolve(); });
        res.on('error', reject);
      }).on('error', reject);
    }
    doGet(url);
  });
}

async function main() {
  console.log('Valley Open — Setup\n');

  if (fs.existsSync(LLAMA_EXE)) {
    console.log('✓ llama-server.exe already exists in bin/');
    console.log('\nRun: npm start');
    return;
  }

  fs.mkdirSync(BIN_DIR, { recursive: true });

  console.log('Fetching latest llama.cpp release...');
  let release;
  try {
    release = await getLatestRelease();
  } catch (e) {
    console.error('Could not fetch release info:', e.message);
    console.log('\nManual setup:');
    console.log('1. Go to https://github.com/ggerganov/llama.cpp/releases/latest');
    console.log('2. Download the Windows x64 zip (e.g. llama-b...-bin-win-avx2-x64.zip)');
    console.log('3. Extract llama-server.exe to bin/llama-server.exe');
    return;
  }

  // Find Windows x64 asset — prefer AVX2 for best CPU compat
  const assets = release.assets || [];
  const asset = assets.find(a => a.name.includes('win') && a.name.includes('avx2') && a.name.includes('x64') && a.name.endsWith('.zip'))
    || assets.find(a => a.name.includes('win') && a.name.includes('x64') && a.name.endsWith('.zip'));

  if (!asset) {
    console.log('Could not find Windows binary in release. Assets:');
    assets.slice(0, 10).forEach(a => console.log(' -', a.name));
    console.log('\nManual: https://github.com/ggerganov/llama.cpp/releases/latest');
    return;
  }

  console.log(`Downloading ${asset.name} (${(asset.size/1024/1024).toFixed(0)} MB)...`);
  const zipPath = path.join(BIN_DIR, 'llama-tmp.zip');
  await downloadFile(asset.browser_download_url, zipPath);

  console.log('Extracting llama-server.exe...');
  try {
    // Use PowerShell to extract on Windows
    execSync(`powershell -Command "Expand-Archive -Path '${zipPath}' -DestinationPath '${BIN_DIR}\\llama-tmp' -Force"`, { stdio: 'inherit' });
    // Find llama-server.exe in extracted files
    const find = execSync(`powershell -Command "Get-ChildItem -Recurse -Path '${BIN_DIR}\\llama-tmp' -Filter 'llama-server.exe' | Select-Object -First 1 -ExpandProperty FullName"`, { encoding: 'utf-8' }).trim();
    if (find && fs.existsSync(find)) {
      fs.copyFileSync(find, LLAMA_EXE);
      console.log('✓ llama-server.exe installed to bin/');
    } else {
      throw new Error('llama-server.exe not found in zip');
    }
    // Cleanup
    fs.rmSync(path.join(BIN_DIR, 'llama-tmp'), { recursive: true, force: true });
    fs.unlinkSync(zipPath);
  } catch (e) {
    console.error('Extraction failed:', e.message);
    console.log(`The zip is at ${zipPath} — manually extract llama-server.exe to bin/`);
    return;
  }

  console.log('\n✓ Setup complete!');
  console.log('Run: npm start');
}

main().catch(console.error);
