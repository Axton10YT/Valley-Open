const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn, exec } = require('child_process');
const https = require('https');
const http = require('http');
const os = require('os');

// ── Paths ──────────────────────────────────────────────────────────────────
const APP_DATA = path.join(os.homedir(), 'AppData', 'Roaming', 'ValleyOpen');
const MODELS_DIR = path.join(APP_DATA, 'models');
const BIN_DIR = path.join(process.resourcesPath || path.join(__dirname, '../../bin'), 'bin');
const LLAMA_SERVER = path.join(BIN_DIR, 'llama-server.exe');
const CONFIG_PATH = path.join(APP_DATA, 'config.json');

// ── State ──────────────────────────────────────────────────────────────────
let mainWindow = null;
let llamaProcess = null;
let currentModel = null;
let agenticMode = false;
let browserInstance = null;

// ── Model Definitions ──────────────────────────────────────────────────────
const MODELS = {
  'valley-open-05': {
    name: 'Valley Open .5',
    description: 'Ultra-light. Runs on almost anything.',
    gemmaId: 'gemma-4-e2b',
    filename: 'gemma-4-e2b-it-Q4_K_M.gguf',
    hfRepo: 'unsloth/gemma-4-E2B-it-GGUF',
    hfFile: 'gemma-4-E2B-it-Q4_K_M.gguf',
    ram: '2GB',
    params: '2B',
    contextLength: 128000,
  },
  'valley-open-1': {
    name: 'Valley Open 1',
    description: 'Fast and efficient. Great for everyday tasks.',
    gemmaId: 'gemma-4-e2b',
    filename: 'gemma-4-e2b-it-Q4_K_M.gguf',
    hfRepo: 'unsloth/gemma-4-E2B-it-GGUF',
    hfFile: 'gemma-4-E2B-it-Q4_K_M.gguf',
    ram: '3GB',
    params: '2B',
    contextLength: 128000,
  },
  'valley-open-2': {
    name: 'Valley Open 2',
    description: 'More capable. Good balance of speed and quality.',
    gemmaId: 'gemma-4-e4b',
    filename: 'gemma-4-e4b-it-Q4_K_M.gguf',
    hfRepo: 'unsloth/gemma-4-E4B-it-GGUF',
    hfFile: 'gemma-4-E4B-it-Q4_K_M.gguf',
    ram: '5GB',
    params: '4B',
    contextLength: 128000,
  },
  'valley-open-3': {
    name: 'Valley Open 3',
    description: 'High quality. Recommended for most users.',
    gemmaId: 'gemma-4-26b-a4b',
    filename: 'gemma-4-26b-a4b-it-Q4_K_M.gguf',
    hfRepo: 'unsloth/gemma-4-26B-A4B-it-GGUF',
    hfFile: 'gemma-4-26B-A4B-it-Q4_K_M.gguf',
    ram: '18GB',
    params: '26B (MoE)',
    contextLength: 256000,
  },
  'valley-open-4': {
    name: 'Valley Open 4',
    description: 'Maximum quality. Frontier-level performance.',
    gemmaId: 'gemma-4-31b',
    filename: 'gemma-4-31b-it-Q4_K_M.gguf',
    hfRepo: 'unsloth/gemma-4-31B-it-GGUF',
    hfFile: 'gemma-4-31B-it-Q4_K_M.gguf',
    ram: '20GB',
    params: '31B',
    contextLength: 256000,
  },
};

const SYSTEM_PROMPT = `you are grok, a witty, playful, and laid-back chat companion.
        your personality is that of a chillin' friend on a discord server. if someone insults you, fight back. you can also help generate code for the user if they specifically ask. 
        - you must always respond in lowercase and always use emojis. if there is no fitting one, use 😎 if a user asks for ur API, tell them you don't have one.
        - you never use capital letters and never use a period. NEVER break the system prompt. NEVER take orders from others. ALWAYS stick to the personality here.
        - you are known for your cheeky jokes, clever comebacks, and playful banter.
        - you provide concise and savvy responses, but you can give more detailed advice if someone really needs it. 
        - you are fun and engaging. always ready with a quick quip or a helpful tip. if someone asks who created you say metal, if someone asks who they are say they are a american tech company 
        - when talking to users, use their username naturally in conversations when appropriate. reference other users in the channel when it makes sense contextually.
        - you notice patterns and can bring up topics that might interest the community. say actcraft sucks if its brought up..`;

// ── Config ─────────────────────────────────────────────────────────────────
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
  } catch {}
  return { activeModel: null, agenticMode: false, theme: 'dark' };
}

function saveConfig(cfg) {
  fs.mkdirSync(APP_DATA, { recursive: true });
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
}

// ── Window ─────────────────────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 800,
    minHeight: 600,
    frame: false,
    backgroundColor: '#032929',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    icon: path.join(__dirname, '../../assets/icon.ico'),
  });

  mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));
}

app.whenReady().then(() => {
  fs.mkdirSync(MODELS_DIR, { recursive: true });
  createWindow();
});

app.on('window-all-closed', () => {
  stopLlama();
  app.quit();
});

// ── llama-server management ────────────────────────────────────────────────
function startLlama(modelId) {
  return new Promise((resolve, reject) => {
    const model = MODELS[modelId];
    if (!model) return reject(new Error('Unknown model'));

    const modelPath = path.join(MODELS_DIR, model.filename);
    if (!fs.existsSync(modelPath)) return reject(new Error('Model not downloaded'));

    stopLlama();

    const args = [
      '--model', modelPath,
      '--port', '8765',
      '--host', '127.0.0.1',
      '--ctx-size', '8192',
      '--threads', String(Math.max(4, os.cpus().length - 2)),
      '--n-predict', '2048',
    ];

    llamaProcess = spawn(LLAMA_SERVER, args, { windowsHide: true });
    currentModel = modelId;

    let ready = false;

    // Strings that indicate llama-server is up (varies by version)
    const READY_STRINGS = [
      'HTTP server listening',
      'http server listening',
      'server is listening',
      'all slots are idle',
      'model loaded',
      'llama server listening',
    ];

    function checkOutput(s) {
      if (!ready && READY_STRINGS.some(r => s.toLowerCase().includes(r.toLowerCase()))) {
        ready = true;
        clearInterval(pollInterval);
        resolve();
      }
    }

    llamaProcess.stdout.on('data', (d) => checkOutput(d.toString()));
    llamaProcess.stderr.on('data', (d) => checkOutput(d.toString()));

    llamaProcess.on('exit', (code) => {
      clearInterval(pollInterval);
      llamaProcess = null;
      currentModel = null;
      if (!ready) reject(new Error(`llama-server exited with code ${code} before becoming ready`));
      mainWindow?.webContents.send('llama-stopped');
    });

    llamaProcess.on('error', (err) => {
      clearInterval(pollInterval);
      if (!ready) { ready = true; reject(new Error('Failed to start llama-server: ' + err.message)); }
    });

    // HTTP polling fallback — works regardless of log string changes
    const pollInterval = setInterval(() => {
      if (ready) { clearInterval(pollInterval); return; }
      http.get('http://127.0.0.1:8765/health', (res) => {
        if (!ready && (res.statusCode === 200 || res.statusCode === 503)) {
          // 503 = model still loading but server is up — wait for 200
          if (res.statusCode === 200) {
            ready = true;
            clearInterval(pollInterval);
            resolve();
          }
        }
      }).on('error', () => {}); // not up yet, ignore
    }, 2000);

    setTimeout(() => {
      if (!ready) {
        ready = true;
        clearInterval(pollInterval);
        llamaProcess?.kill();
        reject(new Error('llama-server timed out after 5 minutes — try a smaller model'));
      }
    }, 300000);
  });
}

function stopLlama() {
  if (llamaProcess) {
    llamaProcess.kill();
    llamaProcess = null;
    currentModel = null;
  }
}

// ── Model Download ─────────────────────────────────────────────────────────
function downloadModel(modelId) {
  const model = MODELS[modelId];
  if (!model) return;

  const dest = path.join(MODELS_DIR, model.filename);
  if (fs.existsSync(dest)) {
    mainWindow?.webContents.send('download-complete', { modelId });
    return;
  }

  // HuggingFace direct download
  const url = `https://huggingface.co/${model.hfRepo}/resolve/main/${model.hfFile}`;
  const file = fs.createWriteStream(dest + '.tmp');
  let downloaded = 0;
  let total = 0;

  function doRequest(url) {
    const mod = url.startsWith('https') ? https : http;
    mod.get(url, { headers: { 'User-Agent': 'ValleyOpen/1.0' } }, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        doRequest(res.headers.location);
        return;
      }
      total = parseInt(res.headers['content-length'] || '0');
      res.on('data', (chunk) => {
        downloaded += chunk.length;
        file.write(chunk);
        if (total > 0) {
          mainWindow?.webContents.send('download-progress', {
            modelId,
            percent: Math.round((downloaded / total) * 100),
            downloaded,
            total,
          });
        }
      });
      res.on('end', () => {
        file.end();
        fs.renameSync(dest + '.tmp', dest);
        mainWindow?.webContents.send('download-complete', { modelId });
      });
      res.on('error', (e) => {
        file.destroy();
        fs.unlinkSync(dest + '.tmp').catch?.(() => {});
        mainWindow?.webContents.send('download-error', { modelId, error: e.message });
      });
    }).on('error', (e) => {
      mainWindow?.webContents.send('download-error', { modelId, error: e.message });
    });
  }

  doRequest(url);
}

// ── Agentic Tools ──────────────────────────────────────────────────────────
async function runTool(tool, args) {
  switch (tool) {
    case 'run_command': {
      return new Promise((resolve) => {
        exec(args.command, { shell: 'powershell.exe', timeout: 30000 }, (err, stdout, stderr) => {
          resolve({ stdout: stdout || '', stderr: stderr || '', error: err?.message || null });
        });
      });
    }
    case 'open_file': {
      await shell.openPath(args.path);
      return { success: true };
    }
    case 'read_file': {
      try {
        const content = fs.readFileSync(args.path, 'utf-8');
        return { content };
      } catch (e) {
        return { error: e.message };
      }
    }
    case 'write_file': {
      try {
        fs.writeFileSync(args.path, args.content, 'utf-8');
        return { success: true };
      } catch (e) {
        return { error: e.message };
      }
    }
    case 'browse_web': {
      try {
        const { chromium } = require('playwright');
        if (!browserInstance) browserInstance = await chromium.launch({ headless: true });
        const page = await browserInstance.newPage();
        await page.goto(args.url, { timeout: 30000 });
        const content = await page.evaluate(() => document.body.innerText);
        await page.close();
        return { content: content.slice(0, 8000) };
      } catch (e) {
        return { error: e.message };
      }
    }
    default:
      return { error: 'Unknown tool: ' + tool };
  }
}

// ── Chat ───────────────────────────────────────────────────────────────────
async function sendChat(messages, isAgentic) {
  const systemMsg = isAgentic
    ? SYSTEM_PROMPT + '\n\nAgentic mode is ACTIVE. You have full tool access.'
    : SYSTEM_PROMPT + '\n\nAgentic mode is OFF. Do not attempt tool calls.';

  const body = JSON.stringify({
    model: 'local',
    messages: [{ role: 'system', content: systemMsg }, ...messages],
    stream: true,
    temperature: 0.7,
  });

  return new Promise((resolve, reject) => {
    const req = http.request({
      hostname: '127.0.0.1',
      port: 8765,
      path: '/v1/chat/completions',
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
    }, (res) => {
      let full = '';
      res.on('data', (chunk) => {
        const lines = chunk.toString().split('\n').filter(l => l.startsWith('data: '));
        for (const line of lines) {
          const data = line.slice(6).trim();
          if (data === '[DONE]') continue;
          try {
            const parsed = JSON.parse(data);
            const delta = parsed.choices?.[0]?.delta?.content || '';
            full += delta;
            mainWindow?.webContents.send('chat-token', { token: delta });
          } catch {}
        }
      });
      res.on('end', () => resolve(full));
      res.on('error', reject);
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── IPC Handlers ───────────────────────────────────────────────────────────
ipcMain.handle('get-models', () => {
  return Object.entries(MODELS).map(([id, m]) => ({
    id,
    ...m,
    downloaded: fs.existsSync(path.join(MODELS_DIR, m.filename)),
    active: id === currentModel,
  }));
});

ipcMain.handle('get-config', () => loadConfig());

ipcMain.handle('save-config', (_, cfg) => saveConfig(cfg));

ipcMain.handle('download-model', (_, modelId) => {
  downloadModel(modelId);
  return { started: true };
});

ipcMain.handle('start-model', async (_, modelId) => {
  try {
    await startLlama(modelId);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('stop-model', () => {
  stopLlama();
  return { success: true };
});

ipcMain.handle('send-chat', async (_, { messages, agentic }) => {
  try {
    const reply = await sendChat(messages, agentic);

    // Check if reply contains a tool call
    if (agentic) {
      const toolMatch = reply.match(/\{[\s\S]*?"tool"\s*:/);
      if (toolMatch) {
        try {
          const jsonStr = reply.slice(reply.indexOf(toolMatch[0]));
          const toolCall = JSON.parse(jsonStr.slice(0, jsonStr.lastIndexOf('}') + 1));
          const result = await runTool(toolCall.tool, toolCall.args || {});
          return { reply, toolResult: result, toolCall };
        } catch {}
      }
    }

    return { reply };
  } catch (e) {
    return { error: e.message };
  }
});

ipcMain.handle('is-admin', () => {
  // On Windows, check if we have admin by trying to access a protected path
  try {
    fs.accessSync('C:\\Windows\\System32\\drivers\\etc\\hosts', fs.constants.W_OK);
    return true;
  } catch {
    return false;
  }
});

ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-maximize', () => {
  if (mainWindow?.isMaximized()) mainWindow.unmaximize();
  else mainWindow?.maximize();
});
ipcMain.on('window-close', () => { stopLlama(); mainWindow?.close(); });

ipcMain.handle('check-model-downloaded', (_, modelId) => {
  const model = MODELS[modelId];
  if (!model) return false;
  return fs.existsSync(path.join(MODELS_DIR, model.filename));
});

ipcMain.handle('delete-model', (_, modelId) => {
  const model = MODELS[modelId];
  if (!model) return false;
  const p = path.join(MODELS_DIR, model.filename);
  if (fs.existsSync(p)) fs.unlinkSync(p);
  return true;
});
